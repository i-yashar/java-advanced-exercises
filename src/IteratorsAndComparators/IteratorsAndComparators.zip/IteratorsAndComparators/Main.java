package IteratorsAndComparators;

import java.util.*;
import java.util.stream.Collectors;

public class Main {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        int n = Integer.parseInt(scanner.nextLine());
        Map<String, Clinic> clinics = new HashMap<>();
        Map<String, Pet> pets = new HashMap<>();

        while(n-- > 0){
            String[] tokens = scanner.nextLine().split(" ");

            switch (tokens[0]){
                case "Create":
                    if(tokens[1].equals("Pet")){
                        Pet myPet = new Pet(tokens[2], Integer.parseInt(tokens[3]), tokens[4]);
                        pets.put(myPet.getName(), myPet);
                    } else {
                        int rooms = Integer.parseInt(tokens[3]);
                        if(rooms % 2 == 0)
                            System.out.println("Invalid Operation!");
                        else {
                            Clinic newClinic = new Clinic(tokens[2], rooms);
                            clinics.put(newClinic.getName(), newClinic);
                        }
                    }
                    break;
                case "Add":
                    String petName = tokens[1];
                    String clinicName = tokens[2];

                    if(!pets.containsKey(petName)){
                        System.out.println("Invalid Operation!");
                    } else {
                        boolean isAdded = clinics.get(clinicName).addPet(pets.get(petName));
                        System.out.println(isAdded);
                    }
                    break;
                case "Release":
                    clinicName = tokens[1];

                    boolean isReleased = clinics.get(clinicName).releasePet();
                    System.out.println(isReleased);
                    break;
                case "HasEmptyRooms":
                    clinicName = tokens[1];

                    System.out.println(clinics.get(clinicName).hasEmptyRooms());
                    break;
                case "Print":
                    if(tokens.length == 2){
                        clinicName = tokens[1];

                        clinics.get(clinicName).print();
                    } else {
                        clinicName = tokens[1];
                        int room = Integer.parseInt(tokens[2]);

                        clinics.get(clinicName).printRoom(room);
                    }
                    break;
            }
        }

//        System.out.println();
    }
}
