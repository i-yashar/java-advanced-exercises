package IteratorsAndComparators;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Scanner;
import java.util.stream.Collectors;

public class Main {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        Stack myStack = new Stack();

        while(true){
            String[] tokens = scanner.nextLine().split("[,]?\\s+");

            if(tokens[0].equals("END")) break;

            switch (tokens[0]){
                case "Push":
                    List<Integer> items = Arrays.stream(Arrays.copyOfRange(tokens, 1, tokens.length)).map(Integer::parseInt).collect(Collectors.toList());
                    myStack.push(items);
                    break;
                case "Pop":
                    myStack.pop();
                    break;
            }
        }
        for (Integer number : myStack) {
            System.out.println(number);
        }
        for (Integer number : myStack) {
            System.out.println(number);
        }
    }
}
