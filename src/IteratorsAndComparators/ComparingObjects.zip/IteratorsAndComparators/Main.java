package IteratorsAndComparators;

import java.util.*;
import java.util.stream.Collectors;

public class Main {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        List<Person> people = new ArrayList<>();

        while(true){
            String[] tokens = scanner.nextLine().split(" ");

            if(tokens[0].equals("END")) break;

            people.add(new Person(tokens[0], Integer.parseInt(tokens[1]), tokens[2]));
        }

        int n = Integer.parseInt(scanner.nextLine());

        Person person = people.get(n - 1);

        int equalCount = (int)people.stream().filter(p -> p.compareTo(person) == 0).count();



        if(equalCount == 1){
            System.out.println("No matches");
        } else {
            System.out.println(equalCount + " " + (people.size() - equalCount) + " " + people.size());
        }
    }
}
