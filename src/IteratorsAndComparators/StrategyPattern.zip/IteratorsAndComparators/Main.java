package IteratorsAndComparators;

import java.util.*;
import java.util.stream.Collectors;

public class Main {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        Set<Person> byName = new TreeSet<>(new PersonNameComparator());
        Set<Person> byAge = new TreeSet<>(new PersonAgeComparator());

        int n = Integer.parseInt(scanner.nextLine());

        while(n-- > 0){
            String[] tokens = scanner.nextLine().split(" ");

            Person newPerson = new Person(tokens[0], Integer.parseInt(tokens[1]));

            byName.add(newPerson);
            byAge.add(newPerson);
        }

        for (Person person : byName) {
            System.out.println(person.getInfo());
        }

        for (Person person : byAge) {
            System.out.println(person.getInfo());
        }
    }
}
