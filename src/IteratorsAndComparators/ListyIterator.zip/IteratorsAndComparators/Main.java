package IteratorsAndComparators;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        ListyIterator myListy = null;

        while(true){
            String[] tokens = scanner.nextLine().split("\\s+");

            if(tokens[0].equals("END")) break;

            String[] items = Arrays.copyOfRange(tokens, 1, tokens.length);

            switch (tokens[0]){
                case "Create":
                    myListy = new ListyIterator(items);
                    break;
                case "Move":
                    System.out.println(myListy.move());
                    break;
                case "Print":
                    myListy.print();
                    break;
                case "HasNext":
                    System.out.println(myListy.hasNext());
                    break;
            }
        }
    }
}
