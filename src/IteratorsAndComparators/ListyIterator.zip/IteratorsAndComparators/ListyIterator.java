package IteratorsAndComparators;

import java.util.ArrayList;
import java.util.List;

public class ListyIterator {
    private List<String> items;
    private int index = 0;

    public ListyIterator(String... items){
        this.items = new ArrayList<>(List.of(items));
    }

    public boolean move(){
        if(index < this.items.size() - 1){
            this.index++;
            return true;
        } else {
            return false;
        }
    }

    public boolean hasNext(){
        return this.index < this.items.size() - 1;
    }

    public void print(){
        if(!this.items.isEmpty())
            System.out.println(this.items.get(index));
        else
            System.out.println("Invalid Operation!");
    }
}
