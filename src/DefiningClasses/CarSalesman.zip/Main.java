package DefiningClasses;

import java.util.*;
import java.util.function.Predicate;
import java.util.stream.Collectors;

public class Main {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        int n = Integer.parseInt(scanner.nextLine());

        List<Car> cars = new ArrayList<>();
        Map<String, Engine> engines = new HashMap<>();

        while(n-- > 0){
            String[] tokens = scanner.nextLine().split(" ");

            String model = tokens[0];
            int power = Integer.parseInt(tokens[1]);

            Engine engine;

            if(tokens.length == 3){
                if(Character.isDigit(tokens[2].charAt(0))){
                    engine = new Engine(model, power, Integer.parseInt(tokens[2]));
                } else {
                    engine = new Engine(model, power, tokens[2]);
                }
            } else if(tokens.length == 2) {
                engine = new Engine(model, power);
            } else {
                engine = new Engine(model, power, Integer.parseInt(tokens[2]), tokens[3]);
            }
            engines.put(engine.getModel(), engine);
        }

        int m = Integer.parseInt(scanner.nextLine());

        while(m-- > 0){
            String[] tokens = scanner.nextLine().split(" ");

            String model = tokens[0];
            String engineModel = tokens[1];

            Car car;

            if(tokens.length == 3){
                if(Character.isDigit(tokens[2].charAt(0))){
                    car = new Car(model, engines.get(engineModel), Integer.parseInt(tokens[2]));
                } else {
                    car = new Car(model, engines.get(engineModel), tokens[2]);
                }
            } else if(tokens.length == 2) {
                car = new Car(model, engines.get(engineModel));
            } else {
                car = new Car(model, engines.get(engineModel), Integer.parseInt(tokens[2]), tokens[3]);
            }
            cars.add(car);
        }

        for (Car car : cars) {
            System.out.println(car.carInfo());
        }

        System.out.println();
    }
}
