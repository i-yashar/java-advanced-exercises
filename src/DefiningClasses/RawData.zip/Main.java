package DefiningClasses;

import java.util.*;
import java.util.function.Predicate;
import java.util.stream.Collectors;

public class Main {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        int n = Integer.parseInt(scanner.nextLine());

        List<Car> cars = new ArrayList<>();

        while(n-- > 0){
            String[] tokens = scanner.nextLine().split(" ");

            String type = tokens[0];
            Engine engine = new Engine(Integer.parseInt(tokens[1]), Integer.parseInt(tokens[2]));
            Cargo cargo = new Cargo(Integer.parseInt(tokens[3]), tokens[4]);
            Tire tire1 = new Tire(Double.parseDouble(tokens[5]), Integer.parseInt(tokens[6]));
            Tire tire2 = new Tire(Double.parseDouble(tokens[7]), Integer.parseInt(tokens[8]));
            Tire tire3 = new Tire(Double.parseDouble(tokens[9]), Integer.parseInt(tokens[10]));
            Tire tire4 = new Tire(Double.parseDouble(tokens[11]), Integer.parseInt(tokens[12]));

            cars.add(new Car(type, engine, cargo, List.of(tire1, tire2, tire3, tire4)));
        }

        String cargoType = scanner.nextLine();

        for (Car car : cars) {
            if(car.getCargo().getType().equals(cargoType)){
                switch (cargoType){
                    case "fragile":
                        if(car.hasALowPressureTire())
                            System.out.println(car.carInfo());
                        break;
                    case "flamable":
                        if(car.hasEnoughPower())
                            System.out.println(car.carInfo());
                        break;
                }
            }
        }
//        System.out.println();
    }
}
