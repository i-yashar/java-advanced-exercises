package DefiningClasses;

import java.util.List;

public class Car {
    private String model;
    private Engine engine;
    private Cargo cargo;
    private List<Tire> tires;

    public Car(String model, Engine engine, Cargo cargo, List<Tire> tires){
        this.model = model;
        this.engine = engine;
        this.cargo = cargo;
        this.tires = tires;
    }

    public String getModel() {
        return model;
    }

    public Engine getEngine() {
        return engine;
    }

    public Cargo getCargo() {
        return cargo;
    }

    public List<Tire> getTires() {
        return tires;
    }

    public boolean hasALowPressureTire(){
        for (Tire tire : tires) {
            if(tire.getPressure() < 1)
                return true;
        }

        return false;
    }

    public boolean hasEnoughPower(){
        return this.getEngine().getPower() > 250;
    }

    public String carInfo(){
        return this.model;
    }
}
