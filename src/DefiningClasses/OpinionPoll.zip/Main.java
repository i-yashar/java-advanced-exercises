package DefiningClasses;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.Scanner;
import java.util.function.Predicate;

public class Main {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        int n = Integer.parseInt(scanner.nextLine());

        List<Person> people = new ArrayList<>();

        Predicate<Integer> isOldEnough = age -> age > 30;

        while(n-- > 0){
            String[] tokens = scanner.nextLine().split("\\s+");

            people.add(new Person(tokens[0], Integer.parseInt(tokens[1])));
        }

        people.stream().filter(p -> isOldEnough.test(p.getAge())).sorted(Comparator.comparing(Person::getName)).forEach(System.out::println);
    }
}
