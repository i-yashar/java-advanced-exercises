package DefiningClasses;

import java.util.*;
import java.util.function.Predicate;
import java.util.stream.Collectors;

public class Main {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        int n = Integer.parseInt(scanner.nextLine());

        List<Employee> employees = new ArrayList<>();

        Map<String, Double> departments = new HashMap<>();

        while(n-- > 0){
            String[] tokens = scanner.nextLine().split(" ");

            String name = tokens[0];
            double salary = Double.parseDouble(tokens[1]);
            String position = tokens[2];
            String department = tokens[3];

            if(tokens.length == 4){
                Employee employee = new Employee(name, salary, position, department);
                employees.add(employee);
            } else if(tokens.length == 5){
                if(tokens[4].contains("@")){
                    String email = tokens[4];
                    Employee employee = new Employee(name, salary, position, department, email);
                    employees.add(employee);
                } else {
                    int age = Integer.parseInt(tokens[4]);
                    Employee employee = new Employee(name, salary, position, department, age);
                    employees.add(employee);
                }
            } else {
                String email = tokens[4];
                int age = Integer.parseInt(tokens[5]);
                Employee employee = new Employee(name, salary, position, department, email, age);
                employees.add(employee);
            }

            departments.putIfAbsent(department, 0.0);
            departments.put(department, departments.get(department) + salary);
        }

        for (Map.Entry<String, Double> entry : departments.entrySet()) {
            departments.put(entry.getKey(), departments.get(entry.getKey()) / departments.size());
        }

        String bestDepartment = "";
        double bestSalary = Double.MIN_VALUE;

        for (Map.Entry<String, Double> entry : departments.entrySet()) {
            if(entry.getValue() > bestSalary){
                bestSalary = entry.getValue();
                bestDepartment = entry.getKey();
            }
        }

        Predicate<String> isGivenDepartment = bestDepartment::equals;

        StringBuilder info = new StringBuilder();

        employees.stream().filter(e -> isGivenDepartment.test(e.getDepartment()))
                .sorted(Comparator.comparingDouble(Employee::getSalary))
                .forEach(e -> info.append(e).append("***"));

        String[] finalInfo = info.toString().split("[*]{3}");

        System.out.println("Highest Average Salary: " + bestDepartment);
        for (int i = finalInfo.length - 1; i >= 0; i--) {
            System.out.println(finalInfo[i]);
        }
//        System.out.println();
    }
}
