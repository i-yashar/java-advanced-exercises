package DefiningClasses;

import java.util.*;
import java.util.function.Predicate;
import java.util.stream.Collectors;

public class Main {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        int n = Integer.parseInt(scanner.nextLine());

        List<Car> cars = new ArrayList<>();

        while(n-- > 0){
            String[] tokens = scanner.nextLine().split(" ");

            String model = tokens[0];
            double fuelAmount = Double.parseDouble(tokens[1]);
            double fuelCost = Double.parseDouble(tokens[2]);

            cars.add(new Car(model, fuelAmount, fuelCost));
        }

        while(true){
            String[] tokens = scanner.nextLine().split(" ");

            if(tokens[0].equals("End")) break;

            String model = tokens[1];
            int distance = Integer.parseInt(tokens[2]);

            for (int i = 0; i < cars.size(); i++) {
                if(cars.get(i).getModel().equals(model)){
                    cars.get(i).drive(distance);
                }
            }
        }

        cars.forEach(System.out::println);
//        System.out.println();
    }
}
