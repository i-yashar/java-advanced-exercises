package Generics;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        List<Box<Double>> myBoxes = new ArrayList<>();

        int n = Integer.parseInt(scanner.nextLine());

        while(n-- > 0){
            myBoxes.add(new Box<>(Double.parseDouble(scanner.nextLine())));
        }

        Box<Double> newBox = new Box<>(Double.parseDouble(scanner.nextLine()));

        int count = Box.<Double>getCount(myBoxes, newBox);
        System.out.println(count);
    }
}
