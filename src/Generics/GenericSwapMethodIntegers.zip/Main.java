package Generics;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        List<Box<Integer>> myBoxes = new ArrayList<>();

        int n = Integer.parseInt(scanner.nextLine());

        while(n-- > 0){
            myBoxes.add(new Box<>(Integer.parseInt(scanner.nextLine())));
        }

        int[] indexes = Arrays.stream(scanner.nextLine().split(" ")).mapToInt(Integer::parseInt).toArray();

        Box.<Integer>swapElements(myBoxes, indexes[0], indexes[1]);

        for (Box<Integer> box : myBoxes) {
            System.out.println(box);
        }
    }
}
