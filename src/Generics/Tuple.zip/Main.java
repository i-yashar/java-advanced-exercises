package Generics;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Scanner;

public class Main {
    public static void main(String[] args) throws IOException {
        BufferedReader reader = new BufferedReader(new InputStreamReader(System.in));

        String[] input = reader.readLine().split("\\s+");

        String firstName = input[0];
        String secondName = input[1];
        String address = input[2];

        StringBuilder nameFull = new StringBuilder();
        nameFull.append(firstName).append(" ").append(secondName);

        Tuple<String, String> firstTuple = new Tuple<>(nameFull.toString(), address);

        input = reader.readLine().split(" ");

        String name = input[0];
        int litres = Integer.parseInt(input[1]);

        Tuple<String, Integer> secondTuple = new Tuple<>(name, litres);


        input = reader.readLine().split("\\s+");
        int newInteger = Integer.parseInt(input[0]);
        double newDouble = Double.parseDouble(input[1]);

        Tuple<Integer, Double> thirdTuple = new Tuple<>(newInteger, newDouble);

        System.out.println(firstTuple.getElementOne() + " -> " + firstTuple.getElementTwo());
        System.out.println(secondTuple.getElementOne() + " -> " + secondTuple.getElementTwo());
        System.out.println(thirdTuple.getElementOne() + " -> " + thirdTuple.getElementTwo());
    }
}
