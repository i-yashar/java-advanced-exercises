package Generics;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        CustomList<String> myList = new CustomList<>();

        while(true){
            String[] tokens = scanner.nextLine().split("\\s+");

            if(tokens[0].equals("END")) break;

            switch (tokens[0]){
                case "Add":
                    String element = tokens[1];
                    myList.add(element);
                    break;
                case "Remove":
                    int index = Integer.parseInt(tokens[1]);
                    myList.remove(index);
                    break;
                case "Contains":
                    System.out.println(myList.contains(tokens[1]));
                    break;
                case "Swap":
                    int index1 = Integer.parseInt(tokens[1]);
                    int index2 = Integer.parseInt(tokens[2]);
                    myList.swap(index1, index2);
                    break;
                case "Greater":
                    System.out.println(myList.countGreaterThan(tokens[1]));
                    break;
                case "Max":
                    System.out.println(myList.getMax());
                    break;
                case "Min":
                    System.out.println(myList.getMin());
                    break;
                case "Print":
                    for (String s : myList) {
                        System.out.println(s);
                    }
                    break;
            }
        }
    }
}
