package Generics;

public class Box<T> {
    private T value;

    public Box(T value){
        this.value = value;
    }

    @Override
    public String toString(){
        StringBuilder outputText = new StringBuilder();
        outputText.append(value.getClass().getName()).append(": ").append(this.value);

        return outputText.toString();
    }
}
