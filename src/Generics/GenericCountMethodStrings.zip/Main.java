package Generics;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        List<Box<String>> myBoxes = new ArrayList<>();

        int n = Integer.parseInt(scanner.nextLine());

        while(n-- > 0){
            myBoxes.add(new Box<>(scanner.nextLine()));
        }

        Box<String> newBox = new Box<>(scanner.nextLine());

        int count = Box.<String>getCount(myBoxes, newBox);
        System.out.println(count);
    }
}
